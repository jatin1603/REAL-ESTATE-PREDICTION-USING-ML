<?php
// Heading
$_['heading_title'] = 'Dashboard';

// Error
$_['error_install'] = 'Waarschuwing: de map Installeren bestaat nog steeds en moet om veiligheidsredenen worden verwijderd!';