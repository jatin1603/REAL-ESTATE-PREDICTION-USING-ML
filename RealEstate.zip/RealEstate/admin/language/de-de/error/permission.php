<?php
// Heading
$_['heading_title']   = 'Geen toestemming!';

// Text
$_['text_permission'] = 'U hebt geen toestemming om deze pagina te openen, raadpleeg uw systeembeheerder.';