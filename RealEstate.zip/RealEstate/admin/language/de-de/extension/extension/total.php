<?php
// Heading
$_['heading_title']     = 'Totalen bestellen';

// Text
$_['text_success']      = 'Succes: u heeft de totalen gewijzigd!';
$_['text_list']         = 'Totale lijst bestellen';

// Column
$_['column_name']       = 'Totalen bestellen';
$_['column_status']     = 'staat';
$_['column_sort_order'] = 'sorteervolgorde';
$_['column_action']     = 'Actie';

// Error
$_['error_permission']  = 'Waarschuwing: u bent niet gemachtigd om totalen te wijzigen!';