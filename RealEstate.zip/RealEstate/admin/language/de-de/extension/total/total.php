<?php
// Heading
$_['heading_title']    = 'Totaal';

// Text
$_['text_total']       = 'Totalen bestellen';
$_['text_success']     = 'Succes: u heeft de totale totalen aangepast!';
$_['text_edit']        = 'Totaal totaal bewerken';

// Entry
$_['entry_status']     = 'staat';
$_['entry_sort_order'] = 'sorteervolgorde';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om totale totalen te wijzigen!';