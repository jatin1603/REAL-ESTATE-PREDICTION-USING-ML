<?php
// Heading
$_['heading_title']    = 'Verzenden';

// Text
$_['text_total']       = 'Totalen bestellen';
$_['text_success']     = 'Succes: u heeft het verzendtotaal aangepast!';
$_['text_edit']        = 'Bewerk verzendtotaal';

// Entry
$_['entry_estimator']  = 'Scheepvaartschatter';
$_['entry_status']     = 'staat';
$_['entry_sort_order'] = 'sorteervolgorde';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om het verzendtotaal te wijzigen!';