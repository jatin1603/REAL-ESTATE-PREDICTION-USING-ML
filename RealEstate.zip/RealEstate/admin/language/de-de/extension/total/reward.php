<?php
// Heading
$_['heading_title']    = 'Beloningspunten';

// Text
$_['text_total']       = 'Totalen bestellen';
$_['text_success']     = 'Succes: je hebt het totale aantal beloningspunten aangepast!';
$_['text_edit']        = 'Bewerk beloningspunten totaal';

// Entry
$_['entry_status']     = 'staat';
$_['entry_sort_order'] = 'sorteervolgorde';

// Error
$_['error_permission'] = 'Waarschuwing: je hebt geen toestemming om het totale aantal beloningspunten te wijzigen!';