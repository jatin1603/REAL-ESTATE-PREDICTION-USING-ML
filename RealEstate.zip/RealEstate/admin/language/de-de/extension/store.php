<?php
// Heading
$_['heading_title']    = 'Extension Store';

// Text
$_['text_success']     = 'Succes: u heeft aangepaste extensies!';
$_['text_list']        = 'Extensielijst';
$_['text_license']     = 'Licentie';
$_['text_free']        = 'Gratis';
$_['text_commercial']  = 'commercieel';
$_['text_category']    = 'Alle categorieën';
$_['text_theme']       = 'Thema's';
$_['text_payment']     = 'Betaling Gateways';
$_['text_shipping']    = 'Verzendmethoden';
$_['text_module']      = 'modules';
$_['text_total']       = 'Totalen bestellen';
$_['text_feed']        = 'Productfeeds';
$_['text_report']      = 'rapporten';
$_['text_other']       = 'anders';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om extensies aan te passen!';