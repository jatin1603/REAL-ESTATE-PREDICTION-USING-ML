<?php
// Heading
$_['heading_title']    = 'Filter';

// Text
$_['text_extension']   = 'uitbreidingen';
$_['text_success']     = 'Succes: u heeft de filtermodule gewijzigd!';
$_['text_edit']        = 'Bewerk filtermodule';

// Entry
$_['entry_status']     = 'staat';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om de filtermodule aan te passen!';