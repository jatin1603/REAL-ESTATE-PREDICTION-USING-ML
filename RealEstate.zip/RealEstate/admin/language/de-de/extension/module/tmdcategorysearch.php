<?php
// Heading
$_['heading_title']    = 'TMD Categorie zoeken';

// Text
$_['text_extension']   = 'uitbreidingen';
$_['text_success']     = 'Succes: je hebt de module Category Search aangepast!';
$_['text_edit']        = 'Edit Category Search Module';

// Entry
$_['entry_status']     = 'staat';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om de module Category Search te wijzigen!';