<?php
// Heading
$_['heading_title']    = 'Agenten naar links balk';

// Text
$_['text_extension']   = 'uitbreidingen';
$_['text_success']     = 'Succes: je hebt de Agents-module aangepast!';
$_['text_edit']        = 'Bewerk Agents Module';

// Entry
$_['entry_status']     = 'staat';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om de Agents-module te wijzigen!';
