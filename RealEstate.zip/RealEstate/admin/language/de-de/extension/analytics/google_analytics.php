<?php
$_['heading_title']    = 'Google Analytics';

// Text
$_['text_extension']   = 'uitbreidingen';
$_['text_success']	   = 'Succes: u heeft Google Analytics aangepast!';
$_['text_signup']      = 'Log in op uw <a href="http://www.google.com/analytics/" target="_blank"> <u> Google Analytics </ u> </a> -account en na het maken en kopiëren van uw website profiel de analysecode in dit veld.';
$_['text_default']     = 'Standaard';

// Entry
$_['entry_code']       = 'Google Analytics-code';
$_['entry_status']     = 'staat';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om Google Analytics te wijzigen!';
$_['error_code']	   = 'Code vereist!';
