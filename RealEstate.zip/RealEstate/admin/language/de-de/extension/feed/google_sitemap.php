<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_extension']   = 'uitbreidingen';
$_['text_success']     = 'Succes: u heeft de Google Sitemap-feed aangepast!';
$_['text_edit']        = 'Bewerk Google Sitemap';

// Entry
$_['entry_status']     = 'staat';
$_['entry_data_feed']  = 'URL van gegevensfeed';

// Error
$_['error_permission'] = 'Waarschuwing: u bent niet gemachtigd om de Google Sitemap-feed te wijzigen!';