<?php
// Heading
$_['heading_title']      = 'Recente galerij';

// Column
$_['column_galleryid']   = 'Galerij-ID';
$_['column_galleryname'] = 'Galerijnaam';
$_['column_totalalbum']  = 'Totaal album';
$_['column_status']      = 'staat';
$_['column_action']      = 'Actie';

