<?php
// Heading
$_['heading_title'] = 'Totaal album';

// Text
$_['text_view']     = 'Bekijk meer...';