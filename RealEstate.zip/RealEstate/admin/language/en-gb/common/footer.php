<?php
// Text
$_['text_footer']  = 'TMD </a> &copy; -' . date('Y') . ' Alle rettigheder forbeholdes.';
$_['text_version'] = 'Version %s';