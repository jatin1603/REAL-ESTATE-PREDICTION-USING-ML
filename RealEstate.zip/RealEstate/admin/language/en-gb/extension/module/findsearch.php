<?php

// Heading

$_['heading_title']    = 'Find Search';

// Text
$_['text_extension']   = 'Extensions';
$_['text_edit']        = 'Edit Find Search Module';
$_['text_status']      = 'Status';

///success msg 
$_['text_success']     = 'Success: You have modified Find Search module!';

//  input Entry
$_['entry_status']     = 'Status';
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Find Search module!';


