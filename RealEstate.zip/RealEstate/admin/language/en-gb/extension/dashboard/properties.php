<?php

// Heading

$_['heading_title']    = 'Properties';
$_['error_permission'] = 'Warning: You do not have permission to modify dashboard online!';