<?php
// Heading
$_['heading_title']  = 'Siden blev ikke fundet!';

// Text
$_['text_not_found'] = 'Siden du leder efter kunne ikke findes! Kontakt venligst din administrator, hvis problemet fortsætter.';