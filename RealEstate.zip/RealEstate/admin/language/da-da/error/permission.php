<?php
// Heading
$_['heading_title']   = 'Adgang nægtet!';

// Text
$_['text_permission'] = 'Du har ikke tilladelse til at få adgang til denne side, se venligst din systemadministrator.';