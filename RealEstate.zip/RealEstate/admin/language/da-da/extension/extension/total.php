<?php
// Heading
$_['heading_title']     = 'Ordre Total';

// Text
$_['text_success']      = 'Succes: Du har ændret totals!';
$_['text_list']         = 'Ordre Total liste';

// Column
$_['column_name']       = 'Ordre Total';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sorteringsrækkefølge';
$_['column_action']     = 'Handling';

// Error
$_['error_permission']  = 'Advarsel: Du har ikke tilladelse til at ændre totaler!';