<?php
// Heading
$_['heading_title']     = 'Forsendelse';

// Text
$_['text_success']      = 'Succes: Du har ændret fragt!';
$_['text_list']         = 'Forsendelsesliste';

// Column
$_['column_name']       = 'Fragtmetode';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sorteringsrækkefølge';
$_['column_action']     = 'Handling';

// Error
$_['error_permission']  = 'Advarsel: Du har ikke tilladelse til at ændre fragt!';