<?php
// Heading
$_['heading_title']    = 'Bekæmpelse af Svig';

// Text
$_['text_success']     = 'Succes: Du har ændret anti-bedrageri!';
$_['text_list']        = 'Anti-Fraud List';

// Column
$_['column_name']      = 'Navn på bekæmpelse af svig';
$_['column_status']    = 'Status';
$_['column_action']    = 'Handling';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre svig!';