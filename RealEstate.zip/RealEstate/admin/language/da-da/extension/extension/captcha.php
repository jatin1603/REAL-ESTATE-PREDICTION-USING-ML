<?php
// Heading
$_['heading_title']    = 'cAPTCHAs';

// Text
$_['text_success']     = 'Succes: Du har ændret captcha!';
$_['text_list']        = 'Captcha List';

// Column
$_['column_name']      = 'Captcha Navn';
$_['column_status']    = 'Status';
$_['column_action']    = 'Handling';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre captcha!';