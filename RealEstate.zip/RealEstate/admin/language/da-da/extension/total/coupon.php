<?php
// Heading
$_['heading_title']    = 'kupon';

// Text
$_['text_total']       = 'Ordre Total';
$_['text_success']     = 'Succes: Du har ændret kupon total!';
$_['text_edit']        = 'Rediger kupon';

// Entry
$_['entry_status']     = 'status';
$_['entry_sort_order'] = 'Sorteringsrækkefølge';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre kupon totalt!';