<?php
// Heading
$_['heading_title']    = 'Gavekort';

// Text
$_['text_total']       = 'Ordre Total';
$_['text_success']     = 'Succes: Du har ændret gavekortet i alt!';
$_['text_edit']        = 'Rediger gavekort i alt';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteringsrækkefølge';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre gavekortet i alt!';