<?php
// Heading
$_['heading_title']    = 'Forsendelse';

// Text
$_['text_total']       = 'Ordre Total';
$_['text_success']     = 'Succes: Du har ændret fragtoverskuddet!';
$_['text_edit']        = 'Rediger fragt i alt';

// Entry
$_['entry_estimator']  = 'Forsendelsesvurdering';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteringsrækkefølge';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre fraktsummen!';