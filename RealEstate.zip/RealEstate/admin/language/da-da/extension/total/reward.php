<?php
// Heading
$_['heading_title']    = 'Belønningspoint';

// Text
$_['text_total']       = 'Ordre Total';
$_['text_success']     = 'Succes: Du har ændret belønningspoint i alt!';
$_['text_edit']        = 'Rediger belønningspoint i alt';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteringsrækkefølge';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre belønningspoint i alt!';