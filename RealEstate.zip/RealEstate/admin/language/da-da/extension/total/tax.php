<?php
// Heading
$_['heading_title']    = 'Skatter';

// Text
$_['text_total']       = 'Ordre Total';
$_['text_success']     = 'Succes: Du har ændret skatter i alt!';
$_['text_edit']        = 'Rediger skat i alt';

// Entry
$_['entry_status']     = 'status';
$_['entry_sort_order'] = 'Sorteringsrækkefølge';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre skatter i alt!';