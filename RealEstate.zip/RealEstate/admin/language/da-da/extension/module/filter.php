<?php
// Heading
$_['heading_title']    = 'Filter';

// Text
$_['text_extension']   = 'Udvidelser';
$_['text_success']     = 'Succes: Du har ændret filtermodul!';
$_['text_edit']        = 'Rediger filtermodul';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre filtermodulet!';