<?php
// Heading
$_['heading_title']    = 'Agents venstre bar';

// Text
$_['text_extension']   = 'Udvidelser';
$_['text_success']     = 'Succes: Du har ændret agenter-modulet!';
$_['text_edit']        = 'Rediger agenter modul';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre Agents-modulet!';
