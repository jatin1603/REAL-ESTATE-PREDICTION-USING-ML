<?php
// Heading
$_['heading_title']    = 'Konto';

// Text
$_['text_extension']   = 'Udvidelser';
$_['text_success']     = 'Succes: Du har ændret konto modul!';
$_['text_edit']        = 'Rediger konto modul';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre kontomodul!';