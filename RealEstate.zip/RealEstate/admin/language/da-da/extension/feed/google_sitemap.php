<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_extension']   = 'Udvidelser';
$_['text_success']     = 'Succes: Du har ændret Google Sitemap-feed!';
$_['text_edit']        = 'Rediger Google Sitemap';

// Entry
$_['entry_status']     = 'status';
$_['entry_data_feed']  = 'Data Feed Url';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre Google Sitemap-feed!';