<?php
// Heading
$_['heading_title']    = 'Samlet salg';

// Text
$_['text_extension']   = 'Udvidelser';
$_['text_success']     = 'Succes: Du har ændret dashboardsalg!';
$_['text_edit']        = 'Rediger Dashboard Salg';
$_['text_view']        = 'Se mere...';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteringsrækkefølge';
$_['entry_width']      = 'Bredde';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre dashboardsalg!';