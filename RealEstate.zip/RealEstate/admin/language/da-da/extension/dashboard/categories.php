<?php
// Heading
$_['heading_title']    = 'Kategorier';

// Text
$_['text_extension']   = 'Udvidelser';
$_['text_success']     = 'Succes: Du har ændret dashboard-kunde!';
$_['text_edit']        = 'Rediger Dashboard-kunde';
$_['text_view']        = 'Se mere...';

// Entry
$_['entry_status']     = 'status';
$_['entry_sort_order'] = 'Sorteringsrækkefølge';
$_['entry_width']      = 'Bredde';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre dashboard-kunde!';