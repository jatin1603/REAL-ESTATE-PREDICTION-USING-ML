<?php
// Heading
$_['heading_title']                = 'Seneste kommentarer';

// Column
$_['column_sr_no']  	 = 'Sr.No.';
$_['column_post']  		 = 'Stolpe';
$_['column_author']      = 'Forfatter';
$_['column_status']     = 'status';
$_['column_action']     = 'Handling';
