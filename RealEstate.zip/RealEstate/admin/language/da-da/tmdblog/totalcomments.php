<?php
// Heading
$_['heading_title'] = '<b>Samlet Kommentarer</b>';

// Text
$_['text_view'] = 'Se mere...';