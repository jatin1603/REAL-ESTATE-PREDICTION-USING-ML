<?php
// Text
$_['text_footer']  = 'TMD </a> &copy; -' . date('Y') . ' All Rights Reserved.';
$_['text_version'] = 'Version %s';